package engine.data.exception;

public class InsufficientTableSizeException  extends RuntimeException {
    public InsufficientTableSizeException(String message) {
        super(message);
    }
}
