package engine.data.exception;

public class CardCountException extends RuntimeException {
    public CardCountException(String message){
        super(message);
    }
}
