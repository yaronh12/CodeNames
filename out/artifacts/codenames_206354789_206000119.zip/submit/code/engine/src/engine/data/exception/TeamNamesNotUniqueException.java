package engine.data.exception;

public class TeamNamesNotUniqueException extends RuntimeException{
    public TeamNamesNotUniqueException(String message) {
        super(message);
    }
}
