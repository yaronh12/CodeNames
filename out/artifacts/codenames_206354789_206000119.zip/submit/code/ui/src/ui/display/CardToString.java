package ui.display;

public class CardToString {
    public String word;
    public String formatLine;

    public CardToString(String word, String formatLine) {
        this.word = word;
        this.formatLine = formatLine;
    }
}
